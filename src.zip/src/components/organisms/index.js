export * from './Footer/Footer';
export * from './Header/Header';
export * from './MovieCard/MovieCard';