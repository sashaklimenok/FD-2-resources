import { Component } from "../../../core";
import '../../molecules'
import '../../atoms'
import { initialFieldsState } from "./initialState";

export class SignUpPage extends Component {

  constructor() {
    super();
    this.state = {
      error: '',
      isLoading: false,
      fields: {
        ...initialFieldsState
      }
    }
  }

  render() {
    return `
      <it-preloader is-loading="${this.state.isLoading}">
        <form class="mt-5">
          <it-input></it-input>
          <it-input></it-input>
          <button type="submit" class="btn btn-primary">Sign in</button>
        </form>
      </it-preloader>
    
    `;
  }
}

customElements.define('sign-up-page', SignUpPage)