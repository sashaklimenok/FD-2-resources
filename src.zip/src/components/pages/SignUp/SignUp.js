import { Component } from "../../../core";

export class SignUpPage extends Component {
  render() {
    return `<h1>SignUp Page<h1>`;
  }
}

customElements.define('sign-up-page', SignUpPage)