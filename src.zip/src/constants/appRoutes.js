export const appRoutes = {
    home: '/',
    admin: '/admin',
    signUp: '/signUp',
    signIn: '/signIn',
    movieDetails: '/movie-details',
    errorPage: '*'
}