export const appRoutes = {
    home: '/',
    admin: '/admin',
    signUp: '/signUp',
    signIn: '/signIn',
    movies: '/movies',
    errorPage: '*'
}