export const appGenres = [
    {
        label: 'All',
        value: 'all'
    },
    {
        label: 'Action',
        value: 'action'
    },
    {
        label: 'Horror',
        value: 'horror'
    },
    {
        label: 'Drama',
        value: 'drama'
    },
    {
        label: 'Fantasy',
        value: 'fantasy'
    },
]