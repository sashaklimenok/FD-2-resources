import { Component } from "./core";
import './components'

export class App extends Component {
  render() {
    return (
      `
        <div id="shell">
          <it-header></it-header>
        </div>
      `
    )
  }
}

customElements.define("my-app", App);
