import { Component } from "./core";
import './components'

export class App extends Component {
  render() {
    return (
      `
        <it-header></it-header>
      `
    )
  }
}

customElements.define("my-app", App);
