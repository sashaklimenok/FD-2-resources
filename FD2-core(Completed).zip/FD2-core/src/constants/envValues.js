export const API_KEY = process.env.API_KEY;
