export class Router extends HTMLElement {
    get outlet() {
        return this.querySelector('it-outlet');
    }

    get routes() {
        return Array.from(this.querySelectorAll('it-route'))
            .map((route) => {
                return {
                    path: route.getAttribute('path'),
                    title: route.getAttribute('title'),
                    component: route.getAttribute('component'),
                }
            })
    }

    navigate(url) {
        const matchedRoute = match(this.routes, url);
    }

    onPopState = () => {
        this.navigate(window.location.pathname)
    }


    connectedCallback() {
        this.navigate(window.location.pathname);
        this.addEventListener('popstate', this.onPopState)
    }

    disconnectedCallback() {
        this.removeEventListener('popstate', this.onPopState)
    }

}

customElements.define('it-router', Router)