# FD2-core
a simple framework for building simple ui
